package edu.berkeley.cs186.database.categories;

public interface StudentTests { /* category marker */ }
